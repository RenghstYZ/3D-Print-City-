
# 3D-Print-City v6

一個 AI 輔助 3D 建模與修圖平台 🎨🖥️

## 功能
- 登入前驗證碼 `Yuting112919`
- 帳號登入/註冊（白名單制）
- 六大分頁：建模、修圖、記錄、個人畫面、快速建模、登出
- 個人畫面輸入 `benyoyo555` → 可更換背景
- 主畫面顯示大 LOGO「3D-Print-City」
- 科技感 UI（漸層 + 動態背景）

## 使用方法
### 前端
```bash
cd frontend
npm install
npm start
```

### 後端
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
