
import React, { useState } from "react";

export default function VerifyCode({ onSuccess }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (code === "Yuting112919") {
      onSuccess();
    } else {
      setError("驗證碼錯誤，請再試一次！");
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h2>請輸入驗證碼</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="password"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="輸入驗證碼"
        />
        <button type="submit">確認</button>
      </form>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
