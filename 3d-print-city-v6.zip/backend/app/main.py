
from fastapi import FastAPI, HTTPException

app = FastAPI()

# 模擬白名單
WHITELIST = ["admin", "Renghst-YZ"]

@app.get("/login/{username}")
def login(username: str):
    if username not in WHITELIST:
        raise HTTPException(status_code=403, detail="帳號不在白名單內")
    return {"message": f"歡迎回來, {username}"}
