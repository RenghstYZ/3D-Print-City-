
import { getState } from './auth.js';
const state = getState();
const cvs = document.getElementById('featCanvas'); const ctx = cvs.getContext('2d');
let features = state.features || [];
function draw(){
  ctx.clearRect(0,0,cvs.width,cvs.height);
  if(state.skeleton && state.skeleton.length){
    const by = Object.fromEntries(state.skeleton.map(j=>[j.name,j]));
    const bones = [['Head','Neck'],['Neck','Spine'],['Spine','Hip'],['Neck','LShoulder'],['LShoulder','LElbow'],['Neck','RShoulder'],['RShoulder','RElbow'],['Hip','LHip'],['LHip','LKnee'],['Hip','RHip'],['RHip','RKnee']];
    ctx.strokeStyle='#5577ff88'; ctx.lineWidth=2;
    bones.forEach(([a,b])=>{ const A=by[a],B=by[b]; if(!A||!B) return; ctx.beginPath(); ctx.moveTo(A.x,A.y); ctx.lineTo(B.x,B.y); ctx.stroke(); });
  }
  ctx.fillStyle='#ffd166'; ctx.strokeStyle='#111';
  features.forEach(p=>{ ctx.beginPath(); ctx.arc(p.x,p.y,6,0,Math.PI*2); ctx.fill(); ctx.stroke(); });
  const ul=document.getElementById('featureList'); if(ul){ ul.innerHTML=''; features.forEach((p,i)=>{ const li=document.createElement('li'); li.textContent=`#${i+1} (${Math.round(p.x)},${Math.round(p.y)}) ${p.tag||''}`; ul.appendChild(li); }); }
}
cvs.addEventListener('click', e=>{
  const r = cvs.getBoundingClientRect();
  const x = e.clientX-r.left, y = e.clientY-r.top;
  const tag = prompt('輸入特徵標籤（可留空）','');
  features.push({x,y,tag});
  state.features = features;
  localStorage.setItem('features', JSON.stringify(features));
  draw();
});
document.getElementById('copyFromSkeleton')?.addEventListener('click',()=>{
  if(!state.skeleton || !state.skeleton.length){ alert('尚未建立骨架'); return; }
  features = state.skeleton.filter(j=>/Head|Neck|Spine|Hip/.test(j.name)).map(j=>({x:j.x,y:j.y,tag:j.name}));
  state.features = features;
  localStorage.setItem('features', JSON.stringify(features));
  draw();
});
document.getElementById('clearFeatures')?.addEventListener('click',()=>{
  features=[]; state.features=features;
  localStorage.setItem('features', JSON.stringify(features));
  draw();
});
document.getElementById('exportFeatures')?.addEventListener('click',()=>{
  const blob = new Blob([JSON.stringify(features,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='features.json'; a.click();
});
draw();
