
const state = {
  token: localStorage.getItem('token') || null,
  user: localStorage.getItem('user') || null,
  skeleton: JSON.parse(localStorage.getItem('skeleton')||'[]'),
  features: JSON.parse(localStorage.getItem('features')||'[]'),
  tries: parseInt(localStorage.getItem('gate_tries')||'0',10),
  lockedUntil: parseInt(localStorage.getItem('gate_locked')||'0',10)
};
export function getState(){ return state; }
function saveState(){
  localStorage.setItem('token', state.token||'');
  localStorage.setItem('user', state.user||'');
  localStorage.setItem('skeleton', JSON.stringify(state.skeleton||[]));
  localStorage.setItem('features', JSON.stringify(state.features||[]));
}
function guard(){
  const p = location.pathname.split('/').pop();
  const publicPages = ['login.html','index.html',''];
  if(!state.token && !publicPages.includes(p)){ location.href='login.html'; }
  else { const who = document.getElementById('whoami'); if(who) who.textContent = state.user || '未登入'; }
}
document.addEventListener('DOMContentLoaded', guard);
document.addEventListener('DOMContentLoaded', ()=>{
  const gate = document.getElementById('gate');
  const gateBtn = document.getElementById('gateBtn');
  const authPanel = document.getElementById('authPanel');
  if(gateBtn){
    const now = Date.now();
    if(state.lockedUntil && now < state.lockedUntil){
      const mins = Math.ceil((state.lockedUntil-now)/60000);
      alert('啟動碼已被鎖定，請 '+mins+' 分鐘後再試'); return;
    }
    gateBtn.onclick = ()=>{
      const v = (gate.value||'').trim();
      if(v==='Yuting112919'){
        state.tries=0; localStorage.removeItem('gate_tries'); localStorage.removeItem('gate_locked');
        authPanel.classList.remove('hidden');
      }else{
        state.tries++; localStorage.setItem('gate_tries', String(state.tries));
        if(state.tries>=10){
          const unlock = Date.now()+2*60*60*1000;
          state.lockedUntil = unlock; localStorage.setItem('gate_locked', String(unlock));
          alert('錯誤超過 10 次，已鎖定 2 小時');
        }else{ alert('啟動碼錯誤（第 '+state.tries+' 次）'); }
      }
    };
  }
  const reg = document.getElementById('doRegister');
  const login = document.getElementById('doLogin');
  const regUser = document.getElementById('regUser');
  const regPass = document.getElementById('regPass');
  const loginUser = document.getElementById('loginUser');
  const loginPass = document.getElementById('loginPass');
  const msg = document.getElementById('loginMsg');
  if(reg){
    reg.onclick = ()=>{
      if(!regUser.value || !regPass.value){ alert('請輸入帳密'); return; }
      localStorage.setItem('user:'+regUser.value, JSON.stringify({user:regUser.value, pass:regPass.value}));
      alert('註冊完成，請以該帳號登入');
    };
  }
  if(login){
    login.onclick = ()=>{
      const u = loginUser.value; const p = loginPass.value;
      const rec = JSON.parse(localStorage.getItem('user:'+u)||'null');
      if(rec && rec.pass===p){
        state.token = Math.random().toString(36).slice(2);
        state.user = u; saveState();
        msg.textContent = '登入成功，正在前往主畫面…';
        setTimeout(()=> location.href='dashboard.html', 600);
      }else{ msg.textContent = '登入失敗，帳號或密碼錯誤'; }
    };
  }
});
