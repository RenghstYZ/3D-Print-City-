
import { getState } from './auth.js';
const state = getState();
const cvs = document.getElementById('skCanvas');
const ctx = cvs.getContext('2d');
const joints = [
  {name:'Head',x:450,y:80},{name:'Neck',x:450,y:130},{name:'Spine',x:450,y:210},{name:'Hip',x:450,y:290},
  {name:'LShoulder',x:390,y:140},{name:'LElbow',x:340,y:190},
  {name:'RShoulder',x:510,y:140},{name:'RElbow',x:560,y:190},
  {name:'LHip',x:410,y:310},{name:'LKnee',x:400,y:380},
  {name:'RHip',x:490,y:310},{name:'RKnee',x:500,y:380}
];
const bones = [['Head','Neck'],['Neck','Spine'],['Spine','Hip'],['Neck','LShoulder'],['LShoulder','LElbow'],['Neck','RShoulder'],['RShoulder','RElbow'],['Hip','LHip'],['LHip','LKnee'],['Hip','RHip'],['RHip','RKnee']];
let dragging=null; const views = {};
['Front','Left','Right','Back','Top'].forEach(k=>{
  const input = document.getElementById('img'+k);
  if(!input) return;
  input.addEventListener('change', e=>{
    const f = e.target.files[0]; if(!f) return;
    const img = new Image();
    img.onload = ()=>{ views[k]=img; draw(); };
    img.src = URL.createObjectURL(f);
  });
});
function draw(){
  ctx.clearRect(0,0,cvs.width,cvs.height);
  for(const k of ['Front','Left','Right','Back','Top']){
    if(views[k]){ ctx.globalAlpha=.25; ctx.drawImage(views[k],0,0,cvs.width,cvs.height); ctx.globalAlpha=1; break; }
  }
  ctx.strokeStyle='#7ec0ff'; ctx.lineWidth=3;
  bones.forEach(([a,b])=>{
    const A=joints.find(j=>j.name===a), B=joints.find(j=>j.name===b);
    ctx.beginPath(); ctx.moveTo(A.x,A.y); ctx.lineTo(B.x,B.y); ctx.stroke();
  });
  ctx.fillStyle='#ffd166'; ctx.strokeStyle='#111';
  joints.forEach(j=>{ ctx.beginPath(); ctx.arc(j.x,j.y,7,0,Math.PI*2); ctx.fill(); ctx.stroke(); });
  const ul = document.getElementById('jointList'); if(ul){
    ul.innerHTML=''; joints.forEach(j=>{ const li=document.createElement('li'); li.textContent=`${j.name} (${Math.round(j.x)},${Math.round(j.y)})`; ul.appendChild(li); });
  }
}
function hit(x,y){ for(const j of joints){ const d=Math.hypot(j.x-x,j.y-y); if(d<12) return j; } return null; }
cvs.addEventListener('mousedown',e=>{ const r=cvs.getBoundingClientRect(); dragging=hit(e.clientX-r.left,e.clientY-r.top); });
cvs.addEventListener('mousemove',e=>{ if(!dragging) return; const r=cvs.getBoundingClientRect(); let x=e.clientX-r.left, y=e.clientY-r.top;
  if(document.getElementById('snapToggle')?.checked){ x=Math.round(x/5)*5; y=Math.round(y/5)*5; }
  dragging.x=x; dragging.y=y; draw();
});
['mouseup','mouseleave'].forEach(ev=>cvs.addEventListener(ev,()=>dragging=null));
document.getElementById('genSkeleton')?.addEventListener('click',()=>{
  alert('已建立基礎骨架（可拖曳關節進一步調整）。');
  state.skeleton = JSON.parse(JSON.stringify(joints));
  localStorage.setItem('skeleton', JSON.stringify(state.skeleton));
});
document.getElementById('resetSkeleton')?.addEventListener('click',()=>{ joints.forEach(j=> j.x=450 ); draw(); });
document.getElementById('exportSkeleton')?.addEventListener('click',()=>{
  state.skeleton = JSON.parse(JSON.stringify(joints));
  localStorage.setItem('skeleton', JSON.stringify(state.skeleton));
  const blob = new Blob([JSON.stringify(state.skeleton,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='skeleton.json'; a.click();
});
draw();
