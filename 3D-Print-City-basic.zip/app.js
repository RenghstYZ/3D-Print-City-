function checkAccess() {
  const code = document.getElementById("access-code").value;
  if (code === "Yuting112919") {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("main-screen").classList.remove("hidden");
  } else {
    alert("密碼錯誤！");
  }
}

function switchPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  document.getElementById("page-" + page).classList.remove("hidden");
}

function unlockProfile() {
  const secret = document.getElementById("secret").value;
  if (secret === "benyoyo555") {
    document.getElementById("profile-extra").classList.remove("hidden");
  } else {
    alert("錯誤的密碼！");
  }
}

function logout() {
  location.reload();
}
