const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { read, write } = require('../models/filedb');
const { jwtSecret } = require('../config');

function token(user){ return jwt.sign({u:user}, jwtSecret, {expiresIn:'7d'}); }

router.post('/register', async(req,res)=>{
  try{
    const { username, password, restrict, allow } = req.body;
    if(!username || !password) return res.status(400).json({message:'缺少帳號或密碼'});
    const users = await read('users');
    if(users[username]) return res.status(409).json({message:'帳號已存在'});
    users[username] = {
      pass: await bcrypt.hash(password, 10),
      createdAt: Date.now()
    };
    await write('users', users);
    // 可選：保存限制設定與白名單
    const settings = await read('records'); // reuse file store for settings
    settings.__restrict = !!restrict;
    settings.__allow = (allow||'').split(',').map(s=>s.trim()).filter(Boolean);
    await write('records', settings);
    res.json({ok:true});
  }catch(e){ console.error(e); res.status(500).json({message:'註冊失敗'}); }
});

router.post('/login', async(req,res)=>{
  try{
    const { username, password } = req.body;
    const users = await read('users');
    const u = users[username];
    if(!u) return res.status(401).json({message:'帳號或密碼錯誤'});
    const ok = await bcrypt.compare(password, u.pass);
    if(!ok) return res.status(401).json({message:'帳號或密碼錯誤'});
    // 檢查限制
    const settings = await read('records');
    if(settings.__restrict && !(settings.__allow||[]).includes(username)){
      return res.status(403).json({message:'已啟用成員限制，您不在允許名單'});
    }
    res.json({token: token(username), username});
  }catch(e){ console.error(e); res.status(500).json({message:'登入失敗'}); }
});

// middleware
function auth(req,res,next){
  const h=req.headers.authorization||''; const t=h.startsWith('Bearer ')?h.slice(7):'';
  if(!t) return res.status(401).json({message:'缺少令牌'});
  try{ req.user = require('jsonwebtoken').verify(t, require('../config').jwtSecret).u; next(); }
  catch(e){ return res.status(401).json({message:'令牌無效'}); }
}
module.exports = router;
module.exports.auth = auth;
