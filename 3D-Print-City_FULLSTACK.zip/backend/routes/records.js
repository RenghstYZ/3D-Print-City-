const express = require('express');
const router = express.Router();
const { read, write } = require('../models/filedb');
const { auth } = require('./auth');

router.post('/save', auth, async(req,res)=>{
  try{
    const { records } = req.body;
    const db = await read('records');
    db[req.user] = records || [];
    await write('records', db);
    res.json({ok:true});
  }catch(e){ console.error(e); res.status(500).json({message:'儲存失敗'}); }
});

router.get('/get', auth, async(req,res)=>{
  try{
    const db = await read('records');
    res.json({records: db[req.user] || []});
  }catch(e){ console.error(e); res.status(500).json({message:'讀取失敗'}); }
});

module.exports = router;
