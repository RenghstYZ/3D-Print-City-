const express = require('express');
const router = express.Router();
const multer  = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { auth } = require('./auth');

const uploadDir = path.join(__dirname,'..','uploads');
fs.ensureDirSync(uploadDir);
const upload = multer({ dest: uploadDir });

// 上傳視圖 / 模型檔（示意）
router.post('/upload', auth, upload.single('file'), async(req,res)=>{
  res.json({ok:true, file: '/uploads/'+path.basename(req.file.path)});
});

// 模擬 AI 生成（僅示意回應）
router.post('/build', auth, async(req,res)=>{
  // 這裡可以接入你之後的 AI 模型或外部 API
  res.json({ok:true, message:'模型生成中（示意回傳）'});
});

module.exports = router;
