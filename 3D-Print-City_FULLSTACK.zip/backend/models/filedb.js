const fs = require('fs-extra');
const path = require('path');
const { dataDir } = require('../config');

const files = {
  users: path.join(dataDir, 'users.json'),
  records: path.join(dataDir, 'records.json')
};

async function ensure(){
  await fs.ensureDir(dataDir);
  for(const k of Object.keys(files)){
    if(!(await fs.pathExists(files[k]))) await fs.writeJson(files[k], k==='users'?{}:{});
  }
}
async function read(name){ await ensure(); return fs.readJson(files[name]); }
async function write(name, data){ await ensure(); return fs.writeJson(files[name], data, {spaces:2}); }

module.exports = { read, write };
