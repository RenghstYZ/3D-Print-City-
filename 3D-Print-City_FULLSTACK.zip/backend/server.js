const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs-extra');

const app = express();
app.use(cors());
app.use(express.json({limit:'20mb'}));

// static uploaded files
app.use('/uploads', express.static(path.join(__dirname,'uploads')));

const auth = require('./routes/auth');
const records = require('./routes/records');
const models = require('./routes/models');

app.use('/auth', auth);
app.use('/records', records);
app.use('/models', models);

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('3D-Print-City API listening on http://localhost:'+PORT));
