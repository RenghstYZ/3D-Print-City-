module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'supersecret-3d-print-city',
  restrictEnabledDefault: false,
  allowListDefault: ['Renghst-YZ'],
  dataDir: require('path').join(__dirname, 'data')
};
