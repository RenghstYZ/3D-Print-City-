# 3D-Print-City · Fullstack

前端：純靜態（可丟 GitHub Pages）  
後端：Node.js + Express（本機 http://localhost:3000）

## 使用方式

### 1) 後端
```bash
cd backend
npm install
npm start
# 伺服器將在 http://localhost:3000
```

### 2) 前端
直接打開 `frontend/index.html`。

- 啟動碼：`Yuting112919`
- 登入後導覽列出現（建模 / 動作架構圖 / 特徵圖 / 多視圖 / 紀錄 / 個人畫面 / 登出）
- 個人畫面輸入 `benyoyo555` 可改背景
- 成員限制：註冊時勾選並填入允許清單（預設包含 `Renghst-YZ`）

### 3) API 摘要
- `POST /auth/register` {username,password,restrict,allow}
- `POST /auth/login` {username,password} → {token}
- `POST /records/save` (Bearer) {records}
- `GET  /records/get`  (Bearer)
- `POST /models/upload` (Bearer, multipart/form-data, field: file)
- `POST /models/build`  (Bearer)

資料儲存在 `backend/data/*.json`。

> 如需換用雲端資料庫，可把 `models/filedb.js` 換成 MongoDB 實作。
