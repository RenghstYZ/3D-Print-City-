// ====== Config ======
const API = (path) => `http://localhost:3000${path}`;

// ====== Helpers ======
const $ = (s)=>document.querySelector(s);
const go = (id)=>{ document.querySelectorAll('.page').forEach(p=>p.classList.remove('active')); $('#'+id).classList.add('active'); };
function toast(msg){ alert(msg); }
function setToken(t){ localStorage.setItem('token', t||''); }
function getToken(){ return localStorage.getItem('token')||''; }
function setUser(u){ localStorage.setItem('user', u||''); $('#whoami').textContent=u||'未登入'; }

// ====== Navigation ======
document.querySelectorAll('nav button[data-go]').forEach(b=>b.addEventListener('click', ()=>go(b.getAttribute('data-go'))));
$('#logoutBtn').addEventListener('click', ()=>{ setUser(''); setToken(''); $('#nav').classList.add('hidden'); go('gate'); });

// ====== Gate / Auth ======
$('#goAuth').addEventListener('click', ()=>{
  if($('#activation').value.trim() !== 'Yuting112919'){ toast('啟動碼錯誤'); return; }
  $('#nav').classList.remove('hidden'); go('home');
});
$('#regBtn').addEventListener('click', async()=>{
  const body={ username: $('#regUser').value.trim(), password: $('#regPass').value, restrict: $('#restrictBox').checked, allow: $('#allowList').value };
  const r=await fetch(API('/auth/register'),{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
  const j=await r.json(); if(!r.ok) return toast(j.message||'註冊失敗'); toast('註冊成功');
});
$('#loginBtn').addEventListener('click', async()=>{
  const body={ username: $('#loginUser').value.trim(), password: $('#loginPass').value };
  const r=await fetch(API('/auth/login'),{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
  const j=await r.json(); if(!r.ok) return toast(j.message||'登入失敗');
  setToken(j.token); setUser(j.username); $('#nav').classList.remove('hidden'); go('home');
});

// ====== Records ======
function renderRecords(){ const rec=JSON.parse(localStorage.getItem('records')||'[]'); $('#recordList').innerHTML=rec.map(x=>`<li>${x}</li>`).join(''); }
function log(m){ const rec=JSON.parse(localStorage.getItem('records')||'[]'); rec.push(new Date().toLocaleString()+' - '+m); localStorage.setItem('records', JSON.stringify(rec)); renderRecords(); }
$('#clearRecords').addEventListener('click', ()=>{ localStorage.removeItem('records'); renderRecords(); });
$('#syncRecords').addEventListener('click', async()=>{
  const rec=JSON.parse(localStorage.getItem('records')||'[]');
  const r=await fetch(API('/records/save'),{method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+getToken()}, body:JSON.stringify({records:rec})});
  const j=await r.json(); if(!r.ok) return toast(j.message||'同步失敗'); toast('同步成功');
});
$('#loadRecords').addEventListener('click', async()=>{
  const r=await fetch(API('/records/get'),{headers:{'Authorization':'Bearer '+getToken()}});
  const j=await r.json(); if(!r.ok) return toast(j.message||'讀取失敗'); localStorage.setItem('records', JSON.stringify(j.records||[])); renderRecords(); toast('已載入伺服器紀錄');
});

// ====== Profile ======
$('#changeBg').addEventListener('click', ()=>{
  if($('#bgPass').value==='benyoyo555'){ document.body.style.background='linear-gradient(135deg,#1a0234,#021f3a,#033326)'; log('更換背景'); }
  else toast('密碼錯誤');
});

// ====== Three.js Viewer Factory ======
function createViewer(id){
  const el=$(id.startsWith('#')?id:'#'+id); const w=el.clientWidth, h=el.clientHeight;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, w/h, .01, 5000); camera.position.set(0,1.2,3);
  const renderer = new THREE.WebGLRenderer({antialias:true}); renderer.setSize(w,h); el.innerHTML=''; el.appendChild(renderer.domElement);
  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  scene.add(new THREE.AmbientLight(0xffffff,.35)); const d=new THREE.DirectionalLight(0xffffff,.95); d.position.set(3,4,5); scene.add(d);
  const grid=new THREE.GridHelper(50,50,0x333333,0x222222); grid.material.opacity=.25; grid.material.transparent=true; scene.add(grid);
  (function loop(){ requestAnimationFrame(loop); controls.update(); renderer.render(scene,camera); })();
  return {scene,camera,renderer,controls,el};
}

// ====== Modeling ======
const mdl = createViewer('modelView'); let currentModel=null;
document.getElementById('modelFile').addEventListener('change', (ev)=>{
  const f=ev.target.files[0]; if(!f) return;
  const R=new FileReader(); R.onload=(e)=>{
    if(f.name.endsWith('.stl')){
      const g=new THREE.STLLoader().parse(e.target.result);
      const mesh=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0x56d6ff,metalness:.1,roughness:.8}));
      if(currentModel) mdl.scene.remove(currentModel); currentModel=mesh; mdl.scene.add(mesh); fillModelInfo(mesh); log('載入模型(STL) '+f.name);
    }else if(f.name.endsWith('.obj')){
      const txt=new TextDecoder().decode(e.target.result); const obj=new THREE.OBJLoader().parse(txt);
      obj.traverse(o=>{ if(o.isMesh) o.material=new THREE.MeshStandardMaterial({color:0x56d6ff}); });
      if(currentModel) mdl.scene.remove(currentModel); currentModel=obj; mdl.scene.add(obj); fillModelInfo(obj); log('載入模型(OBJ) '+f.name);
    }else toast('不支援格式');
  }; R.readAsArrayBuffer(f);
});
function fillModelInfo(obj){
  let verts=0, box=new THREE.Box3(); obj.traverse(o=>{ if(o.isMesh){ o.geometry.computeBoundingBox(); box.expandByObject(o); verts += o.geometry.attributes.position ? o.geometry.attributes.position.count : 0; }});
  const s=box.getSize(new THREE.Vector3());
  $('#modelInfo').innerHTML=`<li>頂點數：${verts}</li><li>尺寸：${s.x.toFixed(3)} × ${s.y.toFixed(3)} × ${s.z.toFixed(3)}</li>`;
}
$('#clearModel').addEventListener('click', ()=>{ if(currentModel){ mdl.scene.remove(currentModel); currentModel=null; $('#modelInfo').innerHTML=''; log('清除模型'); } });
$('#toSk').addEventListener('click', ()=>{ if(!currentModel) return toast('先載入模型'); if(skMesh) sk.scene.remove(skMesh); skMesh=currentModel.clone(); tint(skMesh,.45,0x00ffd5); sk.scene.add(skMesh); go('skeleton'); });
$('#toFt').addEventListener('click', ()=>{ if(!currentModel) return toast('先載入模型'); if(ftMesh) ft.scene.remove(ftMesh); ftMesh=currentModel.clone(); tint(ftMesh,.3,0x00ffd5); ft.scene.add(ftMesh); go('features'); });
function tint(obj, alpha, color){ obj.traverse(o=>{ if(o.isMesh){ o.material=o.material.clone(); o.material.opacity=alpha; o.material.transparent=true; o.material.color.set(color); }}); }

// ====== Skeleton ======
const sk = createViewer('skView'); let skMesh=null, skGroup=null, skJoints=[], dragOn=false, dragging=null, dragPlane=null, offset=new THREE.Vector3();
$('#skFile').addEventListener('change', (ev)=>{
  const f=ev.target.files[0]; if(!f) return; const R=new FileReader();
  R.onload=(e)=>{
    if(f.name.endsWith('.stl')){
      const g=new THREE.STLLoader().parse(e.target.result);
      const mesh=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0x00ffd5,opacity:.5,transparent:true}));
      if(skMesh) sk.scene.remove(skMesh); skMesh=mesh; sk.scene.add(mesh); log('架構載入 STL');
    }else{
      const txt=new TextDecoder().decode(e.target.result); const obj=new THREE.OBJLoader().parse(txt);
      obj.traverse(o=>{ if(o.isMesh) o.material=new THREE.MeshStandardMaterial({color:0x00ffd5,opacity:.5,transparent:true}); });
      if(skMesh) sk.scene.remove(skMesh); skMesh=obj; sk.scene.add(obj); log('架構載入 OBJ');
    }
  }; R.readAsArrayBuffer(f);
});
$('#showSkMesh').addEventListener('change', e=>{ if(skMesh) skMesh.visible=e.target.checked; });
$('#genSk').addEventListener('click', ()=>{
  if(!skMesh) return toast('請先提供模型或從建模複製');
  // 取包圍盒，建立 3 個關節（起點-中點-終點）
  const pts=[]; skMesh.traverse(o=>{ if(o.isMesh){ const pos=o.geometry.attributes.position, m=o.matrixWorld; for(let i=0;i<(pos?.count||0);i++){ pts.push(new THREE.Vector3(pos.getX(i),pos.getY(i),pos.getZ(i)).applyMatrix4(m)); } } });
  if(pts.length<3) return toast('頂點不足');
  const box=new THREE.Box3().setFromPoints(pts), c=box.getCenter(new THREE.Vector3()), s=box.getSize(new THREE.Vector3());
  const axis='y', v=new THREE.Vector3(0,1,0), L=s.y; const a=c.clone().addScaledVector(v,-L/2), b=c.clone(), d=c.clone().addScaledVector(v,L/2);
  if(skGroup){ sk.scene.remove(skGroup); skJoints=[]; }
  const grp=new THREE.Group(), r=Math.max(s.x,s.y,s.z)*.02||.05;
  const sph=(p)=>{const m=new THREE.Mesh(new THREE.SphereGeometry(r,18,18), new THREE.MeshStandardMaterial({color:0xff8800})); m.position.copy(p); return m;}
  const ln=(A,B)=>new THREE.Line(new THREE.BufferGeometry().setFromPoints([A,B]), new THREE.LineBasicMaterial({color:0xffcc00}));
  grp.add(ln(a,b)); grp.add(ln(b,d)); skJoints=[sph(a),sph(b),sph(d)]; skJoints.forEach(j=>grp.add(j));
  skGroup=grp; sk.scene.add(grp); renderJoints();
  log('生成骨架');
});
$('#resetSk').addEventListener('click', ()=>{ if(skGroup){ sk.scene.remove(skGroup); skGroup=null; skJoints=[]; renderJoints(); log('重置骨架'); } });
$('#dragToggle').addEventListener('click', (e)=>{ dragOn=!dragOn; e.target.textContent='拖曳節點：'+(dragOn?'開':'關'); });
function renderJoints(){ $('#jointList').innerHTML=skJoints.map((j,i)=>`<li>#${i} (${j.position.x.toFixed(2)},${j.position.y.toFixed(2)},${j.position.z.toFixed(2)})</li>`).join(''); }
sk.renderer.domElement.addEventListener('pointerdown',(ev)=>{
  if(!dragOn||!skGroup) return; const rect=sk.renderer.domElement.getBoundingClientRect();
  const mouse=new THREE.Vector2(((ev.clientX-rect.left)/rect.width)*2-1, -((ev.clientY-rect.top)/rect.height)*2+1);
  const ray=new THREE.Raycaster(); ray.setFromCamera(mouse, sk.camera); const hits=ray.intersectObjects(skJoints,true);
  if(hits.length){ dragging=hits[0].object; const normal=new THREE.Vector3().subVectors(sk.camera.position, hits[0].point).normalize();
    dragPlane=new THREE.Plane().setFromNormalAndCoplanarPoint(normal, hits[0].point.clone()); const _p=new THREE.Vector3(); ray.ray.intersectPlane(dragPlane,_p); offset.copy(_p).sub(dragging.position); }
});
sk.renderer.domElement.addEventListener('pointermove',(ev)=>{
  if(!dragging||!dragPlane) return; const rect=sk.renderer.domElement.getBoundingClientRect();
  const mouse=new THREE.Vector2(((ev.clientX-rect.left)/rect.width)*2-1, -((ev.clientY-rect.top)/rect.height)*2+1);
  const ray=new THREE.Raycaster(); ray.setFromCamera(mouse, sk.camera); const hit=new THREE.Vector3(); if(ray.ray.intersectPlane(dragPlane,hit)){ dragging.position.copy(hit.sub(offset)); renderJoints(); }
});
window.addEventListener('pointerup', ()=>{ dragging=null; dragPlane=null; });

function skToMesh(){
  if(!skJoints.length) return null;
  const group=new THREE.Group(); const r=.03;
  skJoints.forEach(j=>{ const s=new THREE.Mesh(new THREE.SphereGeometry(r,16,16), new THREE.MeshStandardMaterial({color:0xff8800})); s.position.copy(j.position); group.add(s); });
  const cyl=(A,B)=>{ const h=A.distanceTo(B); if(h<=1e-6) return null; const g=new THREE.CylinderGeometry(r*0.6,r*0.6,h,12);
    const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0xffcc00})); const mid=A.clone().add(B).multiplyScalar(.5); m.position.copy(mid);
    const dir=new THREE.Vector3().subVectors(B,A).normalize(); const quat=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir); m.setRotationFromQuaternion(quat); return m; };
  if(skJoints[0]&&skJoints[1]){ const m=cyl(skJoints[0].position, skJoints[1].position); if(m) group.add(m); }
  if(skJoints[1]&&skJoints[2]){ const m=cyl(skJoints[1].position, skJoints[2].position); if(m) group.add(m); }
  return group;
}

// Export
function saveBlob(blob, name){ const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000); }
$('#expSkGLTF').addEventListener('click', ()=>{ if(!skGroup) return toast('沒有骨架'); const ex=new THREE.GLTFExporter(); ex.parse(skGroup,g=>saveBlob(new Blob([JSON.stringify(g)],{type:'application/json'}),'skeleton.gltf')); });
$('#expSkSTL').addEventListener('click', ()=>{ const m=skToMesh(); if(!m) return toast('沒有骨架'); const ex=new THREE.STLExporter(); saveBlob(new Blob([ex.parse(m)],{type:'application/sla'}),'skeleton.stl'); });
$('#expSkOBJ').addEventListener('click', ()=>{ const m=skToMesh(); if(!m) return toast('沒有骨架'); const ex=new THREE.OBJExporter(); saveBlob(new Blob([ex.parse(m)],{type:'text/plain'}),'skeleton.obj'); });
$('#makeDirect').addEventListener('click', ()=>toast('示意：直接製作'));
$('#makeAfter').addEventListener('click', ()=>toast('示意：調整後製作'));

// ====== Features ======
const ft = createViewer('ftView'); let ftMesh=null, ftGroup=null, ftAdd=false, features=[];
$('#copySk').addEventListener('click', ()=>{
  if(!skGroup) return toast('先在架構圖建立骨架');
  if(ftGroup) ft.scene.remove(ftGroup); ftGroup=skGroup.clone(); ft.scene.add(ftGroup);
  if(skMesh){ if(ftMesh) ft.scene.remove(ftMesh); ftMesh=skMesh.clone(); ftMesh.traverse(o=>{ if(o.isMesh){o.material=o.material.clone(); o.material.opacity=.3; o.material.transparent=true;} }); ft.scene.add(ftMesh); }
});
$('#showFtMesh').addEventListener('change', e=>{ if(ftMesh) ftMesh.visible=e.target.checked; });
$('#ftAdd').addEventListener('click', ()=>{ ftAdd=true; });
$('#ftDone').addEventListener('click', ()=>{ ftAdd=false; });
$('#ftUndo').addEventListener('click', ()=>{ const it=features.pop(); if(it){ ft.scene.remove(it.sphere); renderFeat(); } });

ft.renderer.domElement.addEventListener('click', (e)=>{
  if(!ftAdd) return;
  const rect=ft.renderer.domElement.getBoundingClientRect();
  const mouse=new THREE.Vector2(((e.clientX-rect.left)/rect.width)*2-1, -((e.clientY-rect.top)/rect.height)*2+1);
  const ray=new THREE.Raycaster(); ray.setFromCamera(mouse, ft.camera);
  const targets=[]; if(ftMesh) ftMesh.traverse(o=>{ if(o.isMesh) targets.push(o); });
  const ints=ray.intersectObjects(targets,true); let p=null; if(ints.length) p=ints[0].point.clone(); else p=ft.camera.position.clone().add(ray.ray.direction.clone().multiplyScalar(1.2));
  // 最近關節
  let near=-1, dmin=1e9; const joints=[]; if(ftGroup) ftGroup.traverse(o=>{ if(o.isMesh && o.geometry instanceof THREE.SphereGeometry) joints.push(o); });
  joints.forEach((j,i)=>{ const d=j.position.distanceTo(p); if(d<dmin){ dmin=d; near=i; } });
  const sph=new THREE.Mesh(new THREE.SphereGeometry(Math.max(0.02,dmin*0.25),16,16), new THREE.MeshStandardMaterial({color:0x55ddff})); sph.position.copy(p); ft.scene.add(sph);
  features.push({pos:p.clone(), sphere:sph, joint:near}); renderFeat();
});
function renderFeat(){ $('#featureList').innerHTML=features.map((f,i)=>`<li>#${i+1} (${f.pos.x.toFixed(2)},${f.pos.y.toFixed(2)},${f.pos.z.toFixed(2)}) → 關節 ${f.joint}</li>`).join(''); }

function allToMesh(){ const g=new THREE.Group(); const sk=skToMesh(); if(sk) g.add(sk); features.forEach(f=>g.add(f.sphere.clone())); return g; }
$('#expAllGLTF').addEventListener('click', ()=>{ const ex=new THREE.GLTFExporter(); ex.parse(allToMesh(), gltf=>saveBlob(new Blob([JSON.stringify(gltf)],{type:'application/json'}),'skeleton_features.gltf')); });
$('#expAllSTL').addEventListener('click', ()=>{ const ex=new THREE.STLExporter(); saveBlob(new Blob([ex.parse(allToMesh())],{type:'application/sla'}),'skeleton_features.stl'); });
$('#expAllOBJ').addEventListener('click', ()=>{ const ex=new THREE.OBJExporter(); saveBlob(new Blob([ex.parse(allToMesh())],{type:'text/plain'}),'skeleton_features.obj'); });

// ====== Multi-View ======
const mv = createViewer('mvView'); const guides={};
function addGuide(where, file){
  const R=new FileReader(); R.onload=(e)=>{ const img=new Image(); img.onload=()=>{ const tex=new THREE.Texture(img); tex.needsUpdate=true;
    const size=2.5; const plane=new THREE.Mesh(new THREE.PlaneGeometry(size,size), new THREE.MeshBasicMaterial({map:tex,transparent:true,opacity:.6,side:THREE.DoubleSide}));
    if(where==='front'){ plane.position.set(0,size*0.2,-1.2); }
    if(where==='back'){ plane.position.set(0,size*0.2, 1.2); plane.rotateY(Math.PI); }
    if(where==='left'){ plane.position.set(-1.2,size*0.2,0); plane.rotateY(Math.PI/2); }
    if(where==='right'){ plane.position.set( 1.2,size*0.2,0); plane.rotateY(-Math.PI/2); }
    if(where==='top'){ plane.position.set(0,1.3,0); plane.rotateX(-Math.PI/2); }
    if(guides[where]) mv.scene.remove(guides[where]); guides[where]=plane; mv.scene.add(plane);
    log('載入視圖 '+where);
  }; img.src=e.target.result; }; R.readAsDataURL(file);
}
['Front','Left','Right','Back','Top'].forEach(k=>{
  const el=$('#mv'+k); if(el) el.addEventListener('change', (ev)=>{ if(ev.target.files[0]) addGuide(k.toLowerCase(), ev.target.files[0]); });
});

// ====== Init ======
(function init(){ renderRecords(); const u=localStorage.getItem('user'); if(u){ $('#nav').classList.remove('hidden'); setUser(u); go('home'); } })();
